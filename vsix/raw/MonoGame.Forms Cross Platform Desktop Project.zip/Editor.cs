﻿using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Editor : Form
    {
        public Editor()
        {
            InitializeComponent();
        }
    }
}
